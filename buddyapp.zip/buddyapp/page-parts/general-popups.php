<!-- Modal Login form -->
<div id="kleo-login-modal" class="kleo-form-modal main-color mfp-hide">

    <?php kleo_get_template_part('page-parts/login-form'); ?>

</div><!-- END Modal Login form -->


<!-- Modal Lost Password form -->
<div id="kleo-lostpass-modal" class="kleo-form-modal main-color mfp-hide">

    <?php kleo_get_template_part('page-parts/forgot-pass-form'); ?>

</div><!-- END Modal Lost Password form -->

